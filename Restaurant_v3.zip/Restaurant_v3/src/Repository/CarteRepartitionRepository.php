<?php

namespace App\Repository;

use App\Entity\CarteRepartition;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @method CarteRepartition|null find($id, $lockMode = null, $lockVersion = null)
 * @method CarteRepartition|null findOneBy(array $criteria, array $orderBy = null)
 * @method CarteRepartition[]    findAll()
 * @method CarteRepartition[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class CarteRepartitionRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, CarteRepartition::class);
    }

    // /**
    //  * @return CarteRepartition[] Returns an array of CarteRepartition objects
    //  */
    /*
    public function findByExampleField($value)
    {
        return $this->createQueryBuilder('c')
            ->andWhere('c.exampleField = :val')
            ->setParameter('val', $value)
            ->orderBy('c.id', 'ASC')
            ->setMaxResults(10)
            ->getQuery()
            ->getResult()
        ;
    }
    */

    /*
    public function findOneBySomeField($value): ?CarteRepartition
    {
        return $this->createQueryBuilder('c')
            ->andWhere('c.exampleField = :val')
            ->setParameter('val', $value)
            ->getQuery()
            ->getOneOrNullResult()
        ;
    }
    */
}
